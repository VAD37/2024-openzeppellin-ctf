---
'openzeppelin-solidity': minor
---

`Math`: Optimized gas cost of `ceilDiv` by using `unchecked`.
