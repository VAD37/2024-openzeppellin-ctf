---
'openzeppelin-solidity': major
---

Upgradeable Contracts: No longer transpile interfaces, libraries, and stateless contracts.
